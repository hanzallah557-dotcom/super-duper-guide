"""
app.py
----------------------------------------------------------------------
Titanic Survival Prediction System - Flask Backend
----------------------------------------------------------------------
Routes:
    GET  /                  -> Home page
    GET  /about              -> About Titanic / project page
    GET  /predict             -> Prediction form page
    POST /predict_result      -> Handle form submission, render result page
    GET  /result              -> Fallback result page (redirects home if empty)
    POST /api/predict         -> JSON REST API for single passenger prediction
    POST /api/batch_predict   -> Upload a CSV, predict every row, download CSV
    GET  /download_pdf        -> Generate a printable prediction summary
    GET  /history              -> View prediction history (session based)

Run with:  python app.py
----------------------------------------------------------------------
"""

import io
import json
import os
import uuid
from datetime import datetime

import joblib
import pandas as pd
from flask import (
    Flask,
    Response,
    jsonify,
    redirect,
    render_template,
    request,
    send_file,
    session,
    url_for,
)

# ----------------------------------------------------------------------
# APP CONFIGURATION
# ----------------------------------------------------------------------
app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "titanic-survival-prediction-secret-key")

MODEL_PATH = os.path.join("model", "titanic_model.pkl")
STATS_PATH = os.path.join("model", "stats.json")

# ----------------------------------------------------------------------
# LOAD MODEL + DASHBOARD STATS AT STARTUP
# ----------------------------------------------------------------------
model_bundle = None
dashboard_stats = {}

if os.path.exists(MODEL_PATH):
    model_bundle = joblib.load(MODEL_PATH)

if os.path.exists(STATS_PATH):
    with open(STATS_PATH) as f:
        dashboard_stats = json.load(f)


# ----------------------------------------------------------------------
# HELPER: Build a passenger dataframe from raw form / JSON input
# ----------------------------------------------------------------------
def build_passenger_dataframe(data: dict) -> pd.DataFrame:
    pclass = int(data["pclass"])
    sex = str(data["sex"]).lower()
    age = float(data["age"])
    fare = float(data["fare"])
    embarked = str(data["embarked"]).upper()
    sibsp = int(data.get("sibsp", 0))
    parch = int(data.get("parch", 0))

    family_size = sibsp + parch + 1
    is_alone = 1 if family_size == 1 else 0

    row = {
        "Pclass": pclass,
        "Sex": sex,
        "Age": age,
        "Fare": fare,
        "Embarked": embarked,
        "SibSp": sibsp,
        "Parch": parch,
        "FamilySize": family_size,
        "IsAlone": is_alone,
    }
    return pd.DataFrame([row]), row


# ----------------------------------------------------------------------
# HELPER: Generate a natural-language explanation for a prediction
# ----------------------------------------------------------------------
def generate_explanation(row: dict, probability: float, survived: bool) -> str:
    reasons = []

    if row["Sex"] == "female":
        reasons.append("female passengers had a much higher survival rate")
    else:
        reasons.append("male passengers had a significantly lower survival rate")

    if row["Pclass"] == 1:
        reasons.append("traveling in 1st class gave access to lifeboats sooner")
    elif row["Pclass"] == 2:
        reasons.append("2nd class passengers had moderate survival odds")
    else:
        reasons.append("3rd class passengers faced the lowest survival odds")

    if row["Age"] <= 12:
        reasons.append("children were prioritized during evacuation")
    elif row["Age"] >= 60:
        reasons.append("older passengers had reduced survival odds")

    if row["IsAlone"] == 1:
        reasons.append("traveling alone slightly reduced the chances of assistance")
    else:
        reasons.append("traveling with family improved coordination during evacuation")

    if row["Fare"] >= 50:
        reasons.append("a higher fare reflects a higher socio-economic status and better cabin location")

    outcome = "high probability of survival" if survived else "low probability of survival"
    joined_reasons = " and ".join(reasons[:2])

    return (
        f"The passenger has a {outcome} ({probability:.1f}%) because {joined_reasons}."
    )


# ----------------------------------------------------------------------
# HELPER: Run the model and package a full result payload
# ----------------------------------------------------------------------
def run_prediction(data: dict) -> dict:
    if model_bundle is None:
        raise RuntimeError("Model is not trained yet. Run train_model.py first.")

    df, row = build_passenger_dataframe(data)
    pipeline = model_bundle["pipeline"]

    proba = pipeline.predict_proba(df)[0]
    survive_probability = float(proba[1]) * 100
    prediction = int(proba[1] >= 0.5)

    explanation = generate_explanation(row, survive_probability, bool(prediction))

    result = {
        "prediction": "Survived" if prediction == 1 else "Did Not Survive",
        "survived": bool(prediction),
        "probability": round(survive_probability, 2),
        "death_probability": round(100 - survive_probability, 2),
        "explanation": explanation,
        "input": row,
        "model_used": model_bundle.get("best_model_name", "Unknown"),
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }
    return result


# ----------------------------------------------------------------------
# ROUTES - PAGES
# ----------------------------------------------------------------------
@app.route("/")
def home():
    return render_template("index.html", stats=dashboard_stats)


@app.route("/about")
def about():
    return render_template("about.html", stats=dashboard_stats)


@app.route("/predict")
def predict_form():
    return render_template("prediction.html")


@app.route("/predict_result", methods=["POST"])
def predict_result():
    try:
        form = request.form
        data = {
            "pclass": form.get("pclass"),
            "sex": form.get("sex"),
            "age": form.get("age"),
            "fare": form.get("fare"),
            "embarked": form.get("embarked"),
            "sibsp": form.get("sibsp", 0),
            "parch": form.get("parch", 0),
        }
        result = run_prediction(data)

        # Save to session-based prediction history (most recent 10)
        history = session.get("history", [])
        history.insert(0, result)
        session["history"] = history[:10]

        return render_template("result.html", result=result)
    except Exception as exc:
        return render_template("prediction.html", error=str(exc))


@app.route("/result")
def result_page():
    history = session.get("history", [])
    if not history:
        return redirect(url_for("predict_form"))
    return render_template("result.html", result=history[0])


@app.route("/history")
def history_page():
    history = session.get("history", [])
    return render_template("history.html", history=history)


@app.route("/history/clear", methods=["POST"])
def clear_history():
    session["history"] = []
    return redirect(url_for("history_page"))


# ----------------------------------------------------------------------
# ROUTES - REST API
# ----------------------------------------------------------------------
@app.route("/api/predict", methods=["POST"])
def api_predict():
    try:
        data = request.get_json(force=True)
        required = ["pclass", "sex", "age", "fare", "embarked"]
        missing = [f for f in required if f not in data]
        if missing:
            return jsonify({"error": f"Missing fields: {missing}"}), 400

        result = run_prediction(data)
        return jsonify({"success": True, "result": result})
    except Exception as exc:
        return jsonify({"success": False, "error": str(exc)}), 400


@app.route("/api/stats", methods=["GET"])
def api_stats():
    return jsonify(dashboard_stats)


@app.route("/api/batch_predict", methods=["POST"])
def api_batch_predict():
    """Accept a CSV upload, predict every row, return a downloadable CSV."""
    try:
        file = request.files.get("file")
        if file is None:
            return jsonify({"error": "No file uploaded"}), 400

        df_input = pd.read_csv(file)
        df_input.columns = [c.strip() for c in df_input.columns]

        required_cols = {"Pclass", "Sex", "Age", "Fare", "Embarked"}
        if not required_cols.issubset(set(df_input.columns)):
            return jsonify({"error": f"CSV must contain columns: {sorted(required_cols)}"}), 400

        df_input["SibSp"] = df_input.get("SibSp", 0)
        df_input["Parch"] = df_input.get("Parch", 0)
        df_input["FamilySize"] = df_input["SibSp"].fillna(0) + df_input["Parch"].fillna(0) + 1
        df_input["IsAlone"] = (df_input["FamilySize"] == 1).astype(int)
        df_input["Sex"] = df_input["Sex"].str.lower()
        df_input["Embarked"] = df_input["Embarked"].fillna("S").str.upper()

        model_features = model_bundle["feature_columns"]
        pipeline = model_bundle["pipeline"]

        X = df_input[model_features]
        probs = pipeline.predict_proba(X)[:, 1]
        preds = (probs >= 0.5).astype(int)

        df_input["Survival_Probability_%"] = (probs * 100).round(2)
        df_input["Predicted_Survival"] = preds
        df_input["Predicted_Survival_Label"] = df_input["Predicted_Survival"].map(
            {1: "Survived", 0: "Did Not Survive"}
        )

        output = io.StringIO()
        df_input.to_csv(output, index=False)
        output.seek(0)

        return Response(
            output.getvalue(),
            mimetype="text/csv",
            headers={
                "Content-Disposition": f"attachment; filename=predictions_{uuid.uuid4().hex[:8]}.csv"
            },
        )
    except Exception as exc:
        return jsonify({"error": str(exc)}), 400


# ----------------------------------------------------------------------
# ERROR HANDLERS
# ----------------------------------------------------------------------
@app.errorhandler(404)
def not_found(e):
    return render_template("404.html"), 404


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
