/* ======================================================================
   TITANIC SURVIVAL PREDICTION SYSTEM — MAIN SCRIPT
====================================================================== */

document.addEventListener('DOMContentLoaded', () => {
  initPageLoader();
  initAOS();
  initThemeToggle();
  initBubbles();
  initNavbarScroll();
  initRippleButtons();
  initTypingEffect();
  initFactorBars();
});

/* ---------- PAGE LOADER ---------- */
function initPageLoader() {
  const loader = document.getElementById('pageLoader');
  if (!loader) return;
  window.addEventListener('load', () => {
    setTimeout(() => loader.classList.add('hide'), 350);
  });
  // Fallback in case load already fired
  setTimeout(() => loader.classList.add('hide'), 1800);
}

/* ---------- AOS INIT ---------- */
function initAOS() {
  if (window.AOS) {
    AOS.init({ duration: 800, once: true, offset: 80, easing: 'ease-out-cubic' });
  }
}

/* ---------- THEME TOGGLE (Dark / Light) ---------- */
function initThemeToggle() {
  const btn = document.getElementById('themeToggle');
  const html = document.documentElement;
  const saved = getStoredTheme();
  if (saved) html.setAttribute('data-theme', saved);

  if (!btn) return;
  btn.addEventListener('click', () => {
    const current = html.getAttribute('data-theme') === 'light' ? 'dark' : 'light';
    html.setAttribute('data-theme', current);
    storeTheme(current);
  });
}
// In-memory fallback (artifacts / previews cannot use localStorage, but this
// is a standalone Flask app served over HTTP, so localStorage is safe here).
function getStoredTheme() {
  try { return localStorage.getItem('titanic_theme'); } catch (e) { return null; }
}
function storeTheme(value) {
  try { localStorage.setItem('titanic_theme', value); } catch (e) { /* no-op */ }
}

/* ---------- FLOATING BUBBLES ---------- */
function initBubbles() {
  const field = document.getElementById('bubbleField');
  if (!field) return;
  const count = window.innerWidth < 768 ? 12 : 22;
  for (let i = 0; i < count; i++) {
    const bubble = document.createElement('span');
    bubble.className = 'bubble';
    const size = Math.random() * 16 + 6;
    bubble.style.width = `${size}px`;
    bubble.style.height = `${size}px`;
    bubble.style.left = `${Math.random() * 100}%`;
    bubble.style.animationDuration = `${Math.random() * 10 + 8}s`;
    bubble.style.animationDelay = `${Math.random() * 10}s`;
    field.appendChild(bubble);
  }
}

/* ---------- NAVBAR SCROLL EFFECT ---------- */
function initNavbarScroll() {
  const nav = document.getElementById('mainNav');
  if (!nav) return;
  window.addEventListener('scroll', () => {
    if (window.scrollY > 40) {
      nav.style.background = 'rgba(7, 16, 33, 0.85)';
      nav.style.boxShadow = '0 8px 30px rgba(0,0,0,0.35)';
    } else {
      nav.style.background = 'rgba(7, 16, 33, 0.55)';
      nav.style.boxShadow = 'none';
    }
  });
}

/* ---------- RIPPLE BUTTON EFFECT ---------- */
function initRippleButtons() {
  document.querySelectorAll('.btn-gold, .btn-outline-ghost').forEach((btn) => {
    btn.classList.add('ripple');
    btn.addEventListener('click', function (e) {
      const rect = this.getBoundingClientRect();
      const circle = document.createElement('span');
      const diameter = Math.max(rect.width, rect.height);
      circle.style.width = circle.style.height = `${diameter}px`;
      circle.style.left = `${e.clientX - rect.left - diameter / 2}px`;
      circle.style.top = `${e.clientY - rect.top - diameter / 2}px`;
      circle.classList.add('ripple-effect');
      this.appendChild(circle);
      setTimeout(() => circle.remove(), 650);
    });
  });
}

/* ---------- TYPING EFFECT (hero subtitle / eyebrow) ---------- */
function initTypingEffect() {
  const el = document.querySelector('[data-typing]');
  if (!el) return;
  const text = el.getAttribute('data-typing');
  el.textContent = '';
  let i = 0;
  function type() {
    if (i <= text.length) {
      el.textContent = text.slice(0, i);
      i++;
      setTimeout(type, 28);
    }
  }
  type();
}

/* ---------- ANIMATE FACTOR / IMPORTANCE BARS ON SCROLL ---------- */
function initFactorBars() {
  const bars = document.querySelectorAll('.factor-bar-fill');
  if (!bars.length) return;
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        const target = entry.target.getAttribute('data-width') || '0';
        entry.target.style.width = `${target}%`;
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.4 });
  bars.forEach((bar) => observer.observe(bar));
}

/* ---------- TOAST NOTIFICATIONS ---------- */
function showToast(message, type = 'info') {
  const container = document.getElementById('toastContainer');
  if (!container) { alert(message); return; }

  const icons = { success: 'fa-circle-check', danger: 'fa-circle-exclamation', info: 'fa-circle-info' };
  const colors = { success: 'var(--success)', danger: 'var(--danger)', info: 'var(--gold)' };

  const toastEl = document.createElement('div');
  toastEl.className = 'toast align-items-center border-0 show mb-2';
  toastEl.style.background = 'rgba(11,31,58,0.92)';
  toastEl.style.backdropFilter = 'blur(12px)';
  toastEl.style.borderLeft = `4px solid ${colors[type] || colors.info}`;
  toastEl.innerHTML = `
    <div class="d-flex">
      <div class="toast-body text-light">
        <i class="fa-solid ${icons[type] || icons.info} me-2" style="color:${colors[type] || colors.info}"></i>${message}
      </div>
      <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
    </div>`;
  container.appendChild(toastEl);
  setTimeout(() => toastEl.remove(), 4500);
}
window.showToast = showToast;

/* ---------- FORM VALIDATION (Prediction Form) ---------- */
function validatePredictionForm(formEl) {
  let valid = true;
  const fields = formEl.querySelectorAll('[required]');
  fields.forEach((field) => {
    if (!field.value || (field.type === 'number' && isNaN(parseFloat(field.value)))) {
      field.classList.add('is-invalid');
      valid = false;
    } else {
      field.classList.remove('is-invalid');
      field.classList.add('is-valid');
    }
  });
  return valid;
}
window.validatePredictionForm = validatePredictionForm;

/* ---------- RESET FORM ---------- */
function resetPredictionForm() {
  const form = document.getElementById('predictionForm');
  if (!form) return;
  form.reset();
  form.querySelectorAll('.is-valid, .is-invalid').forEach((el) => el.classList.remove('is-valid', 'is-invalid'));
  showToast('Form has been reset', 'info');
}
window.resetPredictionForm = resetPredictionForm;

/* ---------- PRINT RESULT ---------- */
function printResult() {
  window.print();
}
window.printResult = printResult;

/* ======================================================================
   CHART.JS HELPERS — used by index.html / result.html via inline scripts
   that call these render functions with data from Flask (dashboard_stats)
====================================================================== */
const CHART_COLORS = {
  gold: '#d9b46a',
  goldBright: '#f2cf7e',
  ocean: '#1c5c8c',
  success: '#3ddc97',
  danger: '#ff6b6b',
  mist: '#cfe4ee',
  grid: 'rgba(234,244,248,0.08)'
};

function baseChartOptions(extra = {}) {
  return Object.assign({
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { labels: { color: CHART_COLORS.mist, font: { family: 'Jost' } } },
      tooltip: { backgroundColor: '#0b1f3a', titleColor: '#f2cf7e', bodyColor: '#eaf4f8' }
    },
    scales: {
      x: { ticks: { color: CHART_COLORS.mist }, grid: { color: CHART_COLORS.grid } },
      y: { ticks: { color: CHART_COLORS.mist }, grid: { color: CHART_COLORS.grid } }
    }
  }, extra);
}
window.CHART_COLORS = CHART_COLORS;
window.baseChartOptions = baseChartOptions;

/* ---------- ANIMATED GAUGE (Result page survival meter) ---------- */
function drawGauge(canvasId, probability, isSurvived) {
  const ctx = document.getElementById(canvasId);
  if (!ctx || !window.Chart) return;
  const color = isSurvived ? CHART_COLORS.success : CHART_COLORS.danger;
  new Chart(ctx, {
    type: 'doughnut',
    data: {
      datasets: [{
        data: [probability, 100 - probability],
        backgroundColor: [color, 'rgba(234,244,248,0.08)'],
        borderWidth: 0,
        circumference: 180,
        rotation: 270,
        cutout: '75%'
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      animation: { animateRotate: true, duration: 1400, easing: 'easeOutCubic' },
      plugins: { legend: { display: false }, tooltip: { enabled: false } }
    }
  });
}
window.drawGauge = drawGauge;

/* ---------- CSV UPLOAD DRAG & DROP (Batch Prediction) ---------- */
function initUploadDrop(dropId, inputId) {
  const drop = document.getElementById(dropId);
  const input = document.getElementById(inputId);
  if (!drop || !input) return;

  drop.addEventListener('click', () => input.click());
  drop.addEventListener('dragover', (e) => { e.preventDefault(); drop.classList.add('dragover'); });
  drop.addEventListener('dragleave', () => drop.classList.remove('dragover'));
  drop.addEventListener('drop', (e) => {
    e.preventDefault();
    drop.classList.remove('dragover');
    if (e.dataTransfer.files.length) {
      input.files = e.dataTransfer.files;
      drop.querySelector('.upload-filename').textContent = e.dataTransfer.files[0].name;
    }
  });
  input.addEventListener('change', () => {
    if (input.files.length) {
      drop.querySelector('.upload-filename').textContent = input.files[0].name;
    }
  });
}
window.initUploadDrop = initUploadDrop;
