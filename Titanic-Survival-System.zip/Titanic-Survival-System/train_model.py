"""
train_model.py
----------------------------------------------------------------------
Titanic Survival Prediction System - Model Training Script
----------------------------------------------------------------------
This script:
    1. Loads the Titanic dataset (dataset/Titanic.csv)
    2. Performs feature engineering (Family Size, Is Alone, etc.)
    3. Builds a preprocessing + modeling Pipeline
       (Imputation -> One-Hot Encoding -> Scaling -> Model)
    4. Trains multiple candidate models:
         - Logistic Regression
         - Random Forest
         - Decision Tree
         - Gradient Boosting
    5. Compares their accuracy on a held-out test split
    6. Selects the best performing model
    7. Saves the trained pipeline with Joblib (model/titanic_model.pkl)
    8. Exports dashboard statistics (dataset stats, chart data,
       feature importance, model comparison) to model/stats.json
       so the Flask app / frontend can render charts without
       re-computing anything at request time.

Run with:  python train_model.py
----------------------------------------------------------------------
"""

import json
import warnings

import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.tree import DecisionTreeClassifier

warnings.filterwarnings("ignore")

DATASET_PATH = "dataset/Titanic.csv"
MODEL_PATH = "model/titanic_model.pkl"
STATS_PATH = "model/stats.json"
RANDOM_STATE = 42


# ----------------------------------------------------------------------
# 1. LOAD DATA
# ----------------------------------------------------------------------
def load_data():
    df = pd.read_csv(DATASET_PATH)
    print(f"[INFO] Loaded dataset with shape: {df.shape}")
    return df


# ----------------------------------------------------------------------
# 2. FEATURE ENGINEERING
# ----------------------------------------------------------------------
def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()

    # Fill missing Embarked with the most common port before engineering
    df["Embarked"] = df["Embarked"].fillna(df["Embarked"].mode()[0])

    # Family Size = siblings/spouses + parents/children + self
    df["FamilySize"] = df["SibSp"] + df["Parch"] + 1

    # Is Alone flag
    df["IsAlone"] = (df["FamilySize"] == 1).astype(int)

    # Keep only the columns needed for modeling + target
    keep_cols = [
        "Survived",
        "Pclass",
        "Sex",
        "Age",
        "Fare",
        "Embarked",
        "SibSp",
        "Parch",
        "FamilySize",
        "IsAlone",
    ]
    return df[keep_cols]


# ----------------------------------------------------------------------
# 3. BUILD PREPROCESSING + MODEL PIPELINE
# ----------------------------------------------------------------------
NUMERIC_FEATURES = ["Age", "Fare", "SibSp", "Parch", "FamilySize"]
CATEGORICAL_FEATURES = ["Pclass", "Sex", "Embarked", "IsAlone"]


def build_preprocessor():
    numeric_transformer = Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
        ]
    )

    categorical_transformer = Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="most_frequent")),
            ("onehot", OneHotEncoder(handle_unknown="ignore")),
        ]
    )

    preprocessor = ColumnTransformer(
        transformers=[
            ("num", numeric_transformer, NUMERIC_FEATURES),
            ("cat", categorical_transformer, CATEGORICAL_FEATURES),
        ]
    )
    return preprocessor


def get_candidate_models():
    return {
        "Logistic Regression": LogisticRegression(max_iter=1000, random_state=RANDOM_STATE),
        "Random Forest": RandomForestClassifier(
            n_estimators=300, max_depth=6, random_state=RANDOM_STATE
        ),
        "Decision Tree": DecisionTreeClassifier(max_depth=5, random_state=RANDOM_STATE),
        "Gradient Boosting": GradientBoostingClassifier(
            n_estimators=200, max_depth=3, learning_rate=0.05, random_state=RANDOM_STATE
        ),
    }


# ----------------------------------------------------------------------
# 4. TRAIN, COMPARE, AND SELECT BEST MODEL
# ----------------------------------------------------------------------
def train_and_compare(X_train, X_test, y_train, y_test, preprocessor):
    results = {}
    fitted_pipelines = {}

    for name, model in get_candidate_models().items():
        pipe = Pipeline(steps=[("preprocessor", preprocessor), ("model", model)])
        pipe.fit(X_train, y_train)
        preds = pipe.predict(X_test)

        acc = accuracy_score(y_test, preds)
        prec = precision_score(y_test, preds)
        rec = recall_score(y_test, preds)
        f1 = f1_score(y_test, preds)

        results[name] = {
            "accuracy": round(acc * 100, 2),
            "precision": round(prec * 100, 2),
            "recall": round(rec * 100, 2),
            "f1_score": round(f1 * 100, 2),
        }
        fitted_pipelines[name] = pipe

        print(f"[RESULT] {name:<20} | Accuracy: {acc * 100:.2f}%  F1: {f1 * 100:.2f}%")

    best_name = max(results, key=lambda k: results[k]["accuracy"])
    best_pipeline = fitted_pipelines[best_name]
    print(f"\n[BEST MODEL] {best_name} selected with {results[best_name]['accuracy']}% accuracy")

    return best_name, best_pipeline, results


# ----------------------------------------------------------------------
# 5. FEATURE IMPORTANCE (best-effort, works for tree models directly,
#    falls back to permutation importance for linear models)
# ----------------------------------------------------------------------
def get_feature_importance(pipeline, X_test, y_test):
    preprocessor = pipeline.named_steps["preprocessor"]
    model = pipeline.named_steps["model"]

    # Reconstruct feature names after one-hot encoding
    cat_encoder = preprocessor.named_transformers_["cat"].named_steps["onehot"]
    cat_names = list(cat_encoder.get_feature_names_out(CATEGORICAL_FEATURES))
    feature_names = NUMERIC_FEATURES + cat_names

    importances = None
    if hasattr(model, "feature_importances_"):
        importances = model.feature_importances_
    elif hasattr(model, "coef_"):
        importances = np.abs(model.coef_[0])

    if importances is None:
        from sklearn.inspection import permutation_importance

        r = permutation_importance(
            pipeline, X_test, y_test, n_repeats=10, random_state=RANDOM_STATE
        )
        importances = r.importances_mean

    imp_df = (
        pd.DataFrame({"feature": feature_names, "importance": importances})
        .groupby("feature", as_index=False)
        .sum()
        .sort_values("importance", ascending=False)
    )

    # Normalize to percentages for nicer chart display
    total = imp_df["importance"].sum()
    imp_df["importance_pct"] = (imp_df["importance"] / total * 100).round(2)

    return imp_df.head(10).to_dict(orient="records")


# ----------------------------------------------------------------------
# 6. DASHBOARD / CHART STATISTICS (computed once, cached to stats.json)
# ----------------------------------------------------------------------
def compute_dashboard_stats(raw_df: pd.DataFrame, model_results: dict, feature_importance: list):
    df = raw_df.copy()
    df["Embarked"] = df["Embarked"].fillna(df["Embarked"].mode()[0])

    total_passengers = int(len(df))
    survivors = int(df["Survived"].sum())
    fatalities = total_passengers - survivors

    survival_by_gender = (
        df.groupby("Sex")["Survived"].mean().mul(100).round(2).to_dict()
    )
    survival_by_class = (
        df.groupby("Pclass")["Survived"].mean().mul(100).round(2).to_dict()
    )
    survival_by_embarked = (
        df.groupby("Embarked")["Survived"].mean().mul(100).round(2).to_dict()
    )

    # Age distribution buckets
    age_bins = [0, 10, 20, 30, 40, 50, 60, 100]
    age_labels = ["0-10", "11-20", "21-30", "31-40", "41-50", "51-60", "60+"]
    age_series = pd.cut(df["Age"].dropna(), bins=age_bins, labels=age_labels)
    age_distribution = age_series.value_counts().sort_index().to_dict()
    age_distribution = {str(k): int(v) for k, v in age_distribution.items()}

    # Fare distribution buckets
    fare_bins = [0, 10, 25, 50, 100, 600]
    fare_labels = ["0-10", "10-25", "25-50", "50-100", "100+"]
    fare_series = pd.cut(df["Fare"].dropna(), bins=fare_bins, labels=fare_labels)
    fare_distribution = fare_series.value_counts().sort_index().to_dict()
    fare_distribution = {str(k): int(v) for k, v in fare_distribution.items()}

    # Correlation heatmap data (numeric columns only)
    corr_cols = ["Survived", "Pclass", "Age", "SibSp", "Parch", "Fare"]
    corr_matrix = df[corr_cols].corr().round(2)
    correlation = {
        "labels": corr_cols,
        "matrix": corr_matrix.values.tolist(),
    }

    stats = {
        "total_passengers": total_passengers,
        "survivors": survivors,
        "fatalities": fatalities,
        "survival_rate": round(survivors / total_passengers * 100, 2),
        "best_model_accuracy": max(v["accuracy"] for v in model_results.values()),
        "charts": {
            "survival_by_gender": {str(k): v for k, v in survival_by_gender.items()},
            "survival_by_class": {str(k): v for k, v in survival_by_class.items()},
            "survival_by_embarked": {str(k): v for k, v in survival_by_embarked.items()},
            "age_distribution": age_distribution,
            "fare_distribution": fare_distribution,
            "correlation_heatmap": correlation,
            "feature_importance": feature_importance,
            "model_comparison": model_results,
        },
    }
    return stats


# ----------------------------------------------------------------------
# MAIN
# ----------------------------------------------------------------------
def main():
    raw_df = load_data()
    df = engineer_features(raw_df)

    X = df.drop(columns=["Survived"])
    y = df["Survived"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=RANDOM_STATE, stratify=y
    )

    preprocessor = build_preprocessor()
    best_name, best_pipeline, results = train_and_compare(
        X_train, X_test, y_train, y_test, preprocessor
    )

    feature_importance = get_feature_importance(best_pipeline, X_test, y_test)

    # Re-fit best model on the FULL dataset for maximum accuracy in production
    final_model = Pipeline(
        steps=[
            ("preprocessor", build_preprocessor()),
            ("model", get_candidate_models()[best_name]),
        ]
    )
    final_model.fit(X, y)

    joblib.dump(
        {
            "pipeline": final_model,
            "best_model_name": best_name,
            "feature_columns": list(X.columns),
        },
        MODEL_PATH,
    )
    print(f"\n[SAVED] Model saved to {MODEL_PATH}")

    stats = compute_dashboard_stats(raw_df, results, feature_importance)
    stats["best_model_name"] = best_name
    with open(STATS_PATH, "w") as f:
        json.dump(stats, f, indent=2)
    print(f"[SAVED] Dashboard stats saved to {STATS_PATH}")


if __name__ == "__main__":
    main()
